import React, { useEffect, useState } from "react";
import {
  Popover,
  PopoverContent,
  PopoverFooter,
  PopoverHeader,
} from "@/components/ui/popover";
import { Table } from "@/components/ui/Table";
import { Loading } from "@/components/ui/Loading";
import { TextInput } from "@/components/ui/text-input";
import { SearchIcon } from "@/components/icons";
import {
  getSAPGoodReceiptCodes,
  getSAPGoodReceiptLines,
  getSAPPurchaseOrderCodes,
  getSAPPurchaseOrderLines,
} from "@/services/sapService";

interface OrderCodeSelectmodalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedBusinessPartner: string;
  selectedDocType: string;
  selectedReferenceCode: string;
  transactionId?: string;
  isDisabled?: boolean;
}

export const OrderCodeSelectmodal: React.FC<OrderCodeSelectmodalProps> = ({
  isOpen,
  onClose,
  selectedBusinessPartner,
  selectedDocType,
  transactionId,
  isDisabled,
  selectedReferenceCode,
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchOrderCode = async () => {
    if (!transactionId || !selectedDocType || !selectedReferenceCode) return;

    try {
      setIsLoading(true);
      setError(null);

      //   const response =
      //     selectedReferenceCode === "po"
      //       ? await getSAPPurchaseOrderCodes(
      //           transactionId,
      //           selectedBusinessPartner,
      //           selectedDocType
      //         )
      //       : await getSAPGoodReceiptCodes(
      //           transactionId,
      //           selectedBusinessPartner,
      //           selectedDocType
      //         );
    } catch (error) {
      setError("Failed to load order codes. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Popover onClose={onClose} size={Popover.Size.LARGE}>
      <PopoverHeader onClose={onClose}>
        Selected{" "}
        {selectedReferenceCode === "po" ? "Purchase Order" : "Good Receipt"}
      </PopoverHeader>
      <PopoverContent>
        <div className="px-4">
          {/* {error && <p className="text-red-500">{error}</p>} */}
          <Table
            className="-mt-4"
            bordered
            isLoading={false}
            head={
              <Table.Row className="-mt-5">
                <Table.Header value="#" />
                <Table.Header value="Item Code" />
                <Table.Header value="Account Code" />
                <Table.Header value="Description" />
                <Table.Header value="Quantity" />
                <Table.Header value="Price" />
                <Table.Header value="Action" />
              </Table.Row>
            }
            //   body={
            //     filteredData && filteredData.length > 0 ? (
            //       filteredData.map((line, index) => (
            //         <Table.Row
            //           key={line.LineNum}
            //           className={
            //             selectLine?.LineNum === line.LineNum
            //               ? "bg-blue-50"
            //               : ""
            //           }
            //         >
            //           <Table.Cell>{index + 1}</Table.Cell>
            //           <Table.Cell>{line.ItemCode ?? "-"}</Table.Cell>
            //           <Table.Cell>{line.AccountCode ?? "-"}</Table.Cell>
            //           <Table.Cell>{line.ItemDescription}</Table.Cell>
            //           <Table.Cell>{line.Quantity}</Table.Cell>
            //           <Table.Cell>{line.Price.toFixed(2)}</Table.Cell>
            //           <Table.Cell>
            //             {/* <button
            //               onClick={() => handleSelect(line)}
            //               className={`rounded-md px-3 py-1.5 text-sm font-semibold shadow-sm focus-visible:outline
            //                 ${
            //                   selectLine?.LineNum === line.LineNum
            //                     ? "bg-blue-600 text-white hover:bg-blue-500"
            //                     : "bg-white text-blue-600 border border-blue-600 hover:bg-blue-50"
            //                 }`}
            //               disabled={isDisabled}
            //             >
            //               {selectLine?.LineNum === line.LineNum
            //                 ? "Selected"
            //                 : "Select"}
            //             </button> */}
            //           </Table.Cell>
            //         </Table.Row>
            //       ))
            //     ) : (
            //       <Table.Row>
            //         <Table.Cell colSpan={7} className="text-center">
            //           No order lines available.
            //         </Table.Cell>
            //       </Table.Row>
            //     )
            //   }
          />
        </div>
      </PopoverContent>
    </Popover>
  );
};
