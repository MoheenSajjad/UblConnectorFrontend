export * from "./DetailItem";
