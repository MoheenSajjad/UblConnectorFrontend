export * from "./upload-icon";
