export * from "./chevrons-rigt-icon";
