export * from "./file-upload-icon";
