export * from "./DetailWrapper";
